<?php if ( is_active_sidebar( 'before-footer' ) ): ?>

    <!-- ******************* Before Footer Widget Area ******************* -->

    <div class="col-md-12 before-footer">

		<?php dynamic_sidebar( 'before-footer' ); ?>

    </div><!-- before-footer -->

<?php endif; ?>
