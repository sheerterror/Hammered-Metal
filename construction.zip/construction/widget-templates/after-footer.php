<?php if ( is_active_sidebar( 'after-footer' ) ): ?>

    <!-- ******************* After Footer Widget Area ******************* -->

    <div class="col-md-12 after-footer">

		<?php dynamic_sidebar( 'after-footer' ); ?>

    </div><!-- after-footer -->

<?php endif; ?>
