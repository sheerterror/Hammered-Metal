<?php if ( is_active_sidebar( 'copyright-footer' ) ): ?>

    <!-- ******************* Copyright Footer Widget Area ******************* -->

    <div class="col-md-6 copyright-footer-item">

		<?php dynamic_sidebar( 'copyright-footer' ); ?>

    </div><!-- copyright-footer -->

<?php endif; ?>
